package br.com.fiap.mp.model;

public enum StatusPedido {
	AGUARDANDO,
	APROVADO,
	ENTREGUE
}
